# Library_Management_System
A simple and functional Library Management System Implemented in python 3 (Tkinter module)
# Installation:
1. Clone repository 
2. Run `entrypoint.py' on your project directory.
3. Ensure all dependencies are installed

# Usage:
1. Issue Book
2. Renew Book
3. Return Book
4. Search Student
5. Search Book
6. Add User
7. Remove User
8. Add Student
9. Remove Student
10. Add Book
11. Remove Book

# Brief Introduction

A student can issue a book for 03 days.After that the student have to renew the book, If the student didn't renew the book within the return date the student have to pay fine @ Rs 1/day.A student can take a maximum of 3 books......


